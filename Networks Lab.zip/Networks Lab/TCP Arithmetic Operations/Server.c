#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(12345);
    server_address.sin_addr.s_addr = INADDR_ANY;

    bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address));
    listen(server_socket, 5);

    printf("Server listening on port 12345...\n");

    int client_socket = accept(server_socket, NULL, NULL);

    double num1, num2, result;
    char operation[1];

    recv(client_socket, &num1, sizeof(num1), 0);
    recv(client_socket, &num2, sizeof(num2), 0);
    recv(client_socket, operation, sizeof(operation), 0);

    switch (operation[0]) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        case '/':
            result = (num2 != 0) ? (num1 / num2) : 0; // Avoid division by zero
            break;
        default:
            result = 0; // Invalid operation
    }

    send(client_socket, &result, sizeof(result), 0);

    close(server_socket);
    return 0;
}

